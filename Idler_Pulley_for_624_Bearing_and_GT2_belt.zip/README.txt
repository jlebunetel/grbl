                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2424284
Idler Pulley for 624 Bearing and GT2 belt by peaberry is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is an idler pulley to suit a 624 bearing (4x13x5mm). The pulley outer diameter is 18mm, internal diameter 13mm and overall height is 8.4mm. The pulley outer channel is 6.4mm high by 1.5mm deep.

Assemble with a 624 bearing, M4 machine screw and an M4 washer to give some clearance for the bearing to rotate.

I made this pulley to stop the belt from slipping off the bearings in this drawing robot:
https://www.thingiverse.com/thing:1517211

There's also a spacer included with 8mm OD x 4mm ID x 3.5mm height, which was needed with the drawing robot, to add a bit of clearance to fit the new pulleys.

# Print Settings

Printer: Anycubic Kossel Linear
Rafts: No
Supports: No
Resolution: 0.2mm layer height, 0.8mm shell thickness
Infill: 20%